﻿namespace StudentInformation.Model
{
    public class Courses
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
