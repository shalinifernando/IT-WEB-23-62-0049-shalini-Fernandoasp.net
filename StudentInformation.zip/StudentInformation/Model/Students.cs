﻿namespace StudentInformation.Model
{
    public class Students
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
