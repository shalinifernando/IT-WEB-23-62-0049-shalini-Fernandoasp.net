﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using StudentInformation.Model;

namespace StudentInformation.Data
{
    public class StudentInformationContext : DbContext
    {
        public StudentInformationContext (DbContextOptions<StudentInformationContext> options)
            : base(options)
        {
        }

        public DbSet<StudentInformation.Model.Students> Students { get; set; } = default!;

        public DbSet<StudentInformation.Model.Courses>? Courses { get; set; }
    }
}
